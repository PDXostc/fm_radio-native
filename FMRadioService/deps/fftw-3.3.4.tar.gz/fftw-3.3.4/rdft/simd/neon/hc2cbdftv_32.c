/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-neon.h"
#include "../common/hc2cbdftv_32.c"
